//
//  ViewController.swift
//  Calculadora
//
//  Created by 2020-1 on 9/4/19.
//  Copyright © 2019 unam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textito: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        textito.text = ""
        // Do any additional setup after loading the view.
    }

    @IBAction func operacion(sender: UIButton){
        
        switch sender.tag {
        case 10:
            textito.text = ""
        case 20:
            textito.text = textito.text! + ""
        case 30:
            textito.text = textito.text! + "%"
        case 40:
            textito.text = textito.text! + "/"
        case 50:
            textito.text = textito.text! + " x "
        case 60:
            textito.text = textito.text! + " + "
        case 70:
            textito.text = textito.text! + " - "
        case 80:
            textito.text = textito.text! + " = "
        case 90:
            textito.text = textito.text! + "."
        default:
            textito.text = textito.text! + "\(sender.tag)"
        }
        
        //print(sender.tag)
    }

}

